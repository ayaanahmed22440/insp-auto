// INSP AUTO — premium UK vehicle-history pricing page; reuses the existing navy/blue visual system, compact motion, and shared checkout URLs.
import { useEffect, useState, type ReactNode } from "react";
import { ArrowUpRight, Check, ChevronDown, FileCheck2, LockKeyhole, MapPin, ScanSearch, ShieldCheck } from "lucide-react";
import { PAYMENT_LINKS } from "@/lib/paymentLinks";
import { SERVICE_TIER_PRICES } from "@/lib/servicePricing";

const plans = [
  {
    key: "basic",
    label: "BASIC",
    name: "Basic Vehicle Report",
    price: SERVICE_TIER_PRICES.basic,
    description: "Essential vehicle information for a more informed purchase.",
    features: ["Vehicle History Report", "Title Verification", "Safety Recall Status", "Vehicle Specifications", "Accident Information", "24/7 Support"],
    cta: "Get Basic Report",
    href: PAYMENT_LINKS.basic,
    popular: false,
  },
  {
    key: "standard",
    label: "STANDARD",
    name: "Standard Vehicle Report",
    price: SERVICE_TIER_PRICES.standard,
    description: "More detailed vehicle information for buyers who want additional checks.",
    features: ["Everything in Basic", "Lien & Ownership Check", "Additional Vehicle Records", "Enhanced Vehicle Information", "24/7 Support"],
    cta: "Get Standard Report",
    href: PAYMENT_LINKS.standard,
    popular: true,
  },
  {
    key: "premium",
    label: "PREMIUM",
    name: "Premium Vehicle Report",
    price: SERVICE_TIER_PRICES.premium,
    description: "Our most comprehensive report option for customers who want the most available information.",
    features: ["Everything in Standard", "Comprehensive Vehicle History", "Extended Ownership Information", "Additional Available Checks", "Priority Support"],
    cta: "Get Premium Report",
    href: PAYMENT_LINKS.premium,
    popular: false,
  },
] as const;

const comparison = [
  ["Vehicle History", true, true, true],
  ["Title Verification", true, true, true],
  ["Safety Recall Status", true, true, true],
  ["Vehicle Specifications", true, true, true],
  ["Accident Information", true, true, true],
  ["Lien & Ownership Check", false, true, true],
  ["Additional Vehicle Records", false, true, true],
  ["Extended Ownership Information", false, false, true],
  ["Support", true, true, true],
] as const;

const faqs = [
  ["What is included in the Basic report?", "The Basic report includes the vehicle history report, title verification, safety recall status, vehicle specifications, accident information, and 24/7 support."],
  ["What's the difference between Basic and Standard?", "Standard adds a Lien & Ownership Check, additional vehicle records, and enhanced vehicle information for buyers who want a broader view."],
  ["Which report should I choose?", "Standard is a strong balance of coverage and price for customers who want more than the essential checks without choosing the most comprehensive option."],
  ["Is checkout secure?", "Checkout is handled through Whop, the selected payment provider. This page does not collect or imitate payment details."],
  ["Can I get a refund?", "Please review the Refund Policy and contact support@inspauto.com with your order number if you need help with a payment or report order."],
  ["How do I receive my report?", "Your order is processed according to the report fulfilment process for the selected product. We do not promise instant automated delivery unless it is stated for that product."],
] as const;

function Reveal({ children, className = "" }: { children: ReactNode; className?: string }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => { const timer = window.setTimeout(() => setVisible(true), 35); return () => window.clearTimeout(timer); }, []);
  return <div className={`pricing-reveal ${visible ? "is-visible" : ""} ${className}`}>{children}</div>;
}

function go(path: string) {
  window.history.pushState({}, "", path);
  window.dispatchEvent(new PopStateEvent("popstate"));
  window.scrollTo({ top: 0, behavior: "smooth" });
}

export default function Pricing() {
  const scrollToPlans = () => document.getElementById("pricing-plans")?.scrollIntoView({ behavior: "smooth", block: "start" });
  return <main className="pricing-page">
    <section className="pricing-hero">
      <div className="container pricing-hero-inner"><Reveal><span className="eyebrow">INSP AUTO</span><h1>Choose the Right Vehicle Report</h1><p>Get the vehicle information you need before making your next purchase. Choose the report that's right for you.</p></Reveal></div>
    </section>

    <section id="pricing-plans" className="pricing-plans section-pad"><div className="container"><Reveal className="pricing-section-intro"><span className="eyebrow">REPORT OPTIONS / UK BUYERS</span><h2>Clear coverage. <em>Useful context.</em></h2></Reveal><div className="premium-plan-grid">{plans.map((plan) => <Reveal className={`premium-plan-card ${plan.popular ? "is-popular" : ""}`} key={plan.key}>{plan.popular && <span className="popular-badge">MOST POPULAR</span>}<span className="premium-plan-label">{plan.label}</span><h3>{plan.name}</h3><div className="premium-price"><span>£</span>{plan.price}</div><p>{plan.description}</p><ul>{plan.features.map((feature) => <li key={feature}><Check size={16} aria-hidden="true" />{feature}</li>)}</ul><button className="button premium-plan-button" onClick={() => window.location.assign(plan.href)}>{plan.cta}<ArrowUpRight size={16} /></button></Reveal>)}</div></div></section>

    <section className="pricing-trust section-pad"><div className="container"><Reveal className="pricing-centered-heading"><span className="eyebrow">WHY INSP AUTO</span><h2>Why Choose INSP AUTO?</h2></Reveal><div className="pricing-trust-grid">{[[FileCheck2, "Comprehensive Information", "Get important information available for your selected report."], [ScanSearch, "Easy to Understand", "Clear report information designed for vehicle buyers."], [LockKeyhole, "Secure Checkout", "Payments are securely handled through our checkout provider."], [MapPin, "UK Focused", "Built for customers researching vehicles in the UK."]].map(([Icon, title, text]) => <Reveal className="pricing-trust-item" key={title as string}><Icon size={23} /><h3>{title as string}</h3><p>{text as string}</p></Reveal>)}</div></div></section>

    <section className="comparison-section section-pad"><div className="container"><Reveal className="pricing-centered-heading"><span className="eyebrow">AT A GLANCE</span><h2>Compare Our Reports</h2></Reveal><div className="comparison-scroll"><table><caption className="sr-only">Comparison of Basic, Standard, and Premium vehicle history reports</caption><thead><tr><th scope="col">Feature</th><th scope="col">Basic</th><th scope="col">Standard</th><th scope="col">Premium</th></tr></thead><tbody>{comparison.map(([feature, basic, standard, premium]) => <tr key={feature}><th scope="row">{feature}</th>{[basic, standard, premium].map((included, index) => <td key={`${feature}-${index}`}>{included ? <Check size={17} aria-label="Included" /> : <span className="comparison-dash" aria-label="Not included">—</span>}</td>)}</tr>)}</tbody></table></div></div></section>

    <section className="pricing-process section-pad"><div className="container"><Reveal className="pricing-centered-heading"><span className="eyebrow">HOW IT WORKS</span><h2>Three steps to <em>more context.</em></h2></Reveal><div className="pricing-process-grid">{[["01", "Choose Your Report", "Select the package that matches your needs."], ["02", "Complete Checkout", "Pay securely through Whop."], ["03", "Receive Your Report", "Your order is processed according to the report fulfilment process."]].map(([number, title, text]) => <Reveal className="pricing-process-item" key={number}><span>{number}</span><h3>{title}</h3><p>{text}</p></Reveal>)}</div></div></section>

    <section className="pricing-faq section-pad"><div className="container pricing-faq-grid"><Reveal><span className="eyebrow">QUESTIONS, ANSWERED</span><h2>Good decisions start with <em>clear answers.</em></h2><p>Still deciding? Review the common questions below or contact our support team.</p><button className="line-button" onClick={() => go("/contact")}>Contact support <ArrowUpRight size={16} /></button></Reveal><Reveal className="faq-list">{faqs.map(([question, answer]) => <details key={question}><summary>{question}<ChevronDown size={18} /></summary><p>{answer}</p></details>)}</Reveal></div></section>

    <section className="pricing-final-cta"><div className="container"><Reveal><span className="eyebrow amber">INSP AUTO / BEFORE YOU BUY</span><h2>Check Before You Buy</h2><p>Don't make a vehicle purchase without knowing as much as possible about its history.</p><button className="button" onClick={scrollToPlans}>Get Your Report <ArrowUpRight size={16} /></button></Reveal></div></section>
  </main>;
}
